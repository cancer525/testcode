package org.test.dataflow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DataflowTaint {
	
	public void bad(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
    
        
        Class.forName("com.mysql.jdbc.Driver");
	
		String url = "jdbc:mysql://localhost:3306/itheima";
		
		Connection dbConnection = DriverManager.getConnection(url, "root", "root");

        /* POTENTIAL FLAW: Read data from a querystring using getParameter */
        data = request.getParameter("name");
        StringBuilder builder = new StringBuilder("<" + data + ">");
        builder.insert(3, data).append("");
        builder.reverse();
        StringBuilder builder2 = new StringBuilder("xxx");
        builder2.append("").append(builder);
        String safe = "yyy";
        String unsafe = safe.replace("y", builder2.toString());
        
        String query = "SELECT * FROM user_data WHERE userid = '" + unsafe + "'";
        Statement statement = dbConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet results = statement.executeQuery(query);      
    }

}
