package org.test.structure;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class StructureTaint {
	
	public void openFile(String name) {
		        try {
		             FileInputStream is = new FileInputStream(name);
		            // read file ...
		        } catch (FileNotFoundException e) {
		             // TODO Auto-generated catch block
		        }
		    }

}
