package org.test.semantic;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SemanticTaint {
	
	 public void bad(String tainted) throws IOException {
	        StringBuilder builder = new StringBuilder("<" + tainted + ">");
	        builder.insert(3, tainted).append("");
	        builder.reverse();
	        StringBuilder builder2 = new StringBuilder("xxx");
	        builder2.append("").append(builder);
	        String safe = "yyy";
	        String unsafe = safe.replace("y", builder2.toString());
	        Runtime.getRuntime().exec(unsafe.toLowerCase().substring(1).intern());
	    }


}
